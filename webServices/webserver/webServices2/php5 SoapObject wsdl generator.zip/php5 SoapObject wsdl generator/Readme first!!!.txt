just put wsdl.class.php and wsdl_test.php in your localhost
and call it form your browser like:
http://localhost/wsdl_test.php  to see the service help 
or
http://localhost/wsdl_test.php?wsdl to see xml format
use it at your own risk.
mail me at maroofi@gmail.com

wsdl_client.php a test file to test the service.