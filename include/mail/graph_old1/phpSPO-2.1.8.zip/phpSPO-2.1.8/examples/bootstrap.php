<?php
require_once(__DIR__ . '/../vendor/autoload.php');
require_once('Settings.php');
require_once(__DIR__ . '/../tests/TestUtilities.php');

