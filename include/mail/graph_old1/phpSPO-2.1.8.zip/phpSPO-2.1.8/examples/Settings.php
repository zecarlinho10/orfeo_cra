<?php

$Settings = array(
	'Url' => "https://mediadev19.sharepoint.com/sites/contoso",
    'OneDriveUrl' => "https://mediadev19-my.SharePoint.com",
	'Password' => "P@ssw0rd",
	'UserName' => "mattim@mediadev19.onmicrosoft.com"
);

$AppSettings = array(
	'TenantName' => "mediadev19.onmicrosoft.com",
	'ClientId' => "13d4cd98-1761-4416-b01c-a641c08d0737",
	'ClientSecret' => "oYM9GUiE4uejyaQ0GuuHj7U",
	'Title' => "Office365 Graph explorer",
	'RedirectUrl' => "http://localhost:8078/GraphExplorer/SignIn.php"
);

