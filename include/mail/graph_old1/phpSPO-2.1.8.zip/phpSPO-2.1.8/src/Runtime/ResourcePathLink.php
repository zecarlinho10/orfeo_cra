<?php


namespace Office365\PHP\Client\Runtime;

/**
 * Resource path  for addressing Links between entities
 */
class ResourcePathLink extends ResourcePath
{

    public function getName()
    {
        // TODO: Implement getValue() method.
    }
}