<?php


namespace Office365\PHP\Client\Runtime;


class Office365Version
{
    const V1 = "v1.0";
    const V2 = "v2.0";
    const Beta = "beta";
}