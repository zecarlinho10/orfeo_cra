<?php


namespace Office365\PHP\Client\Runtime\OData;


class ODataException extends \Exception
{

}