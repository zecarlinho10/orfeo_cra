<?php


namespace Office365\PHP\Client\Runtime\OData;


class ODataMetadataLevel
{
    const Verbose = "verbose";
    const NoMetadata = "nometadata";
    const MinimalMetadata = "minimalmetadata";
}