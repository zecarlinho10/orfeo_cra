<?php


namespace Office365\PHP\Client\Runtime\OData;


class AtomFormat extends ODataFormat
{

    /**
     * @return string
     */
    public function getMediaType()
    {
        // TODO: Implement getMediaType() method.
    }
}