<?php


namespace Office365\PHP\Client\Runtime;


abstract class FormatType
{
    const Json = 1;
    const Xml = 2;
    const Atom = 3;
}