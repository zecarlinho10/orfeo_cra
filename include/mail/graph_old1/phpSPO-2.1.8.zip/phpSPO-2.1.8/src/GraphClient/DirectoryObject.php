<?php


namespace Office365\PHP\Client\GraphClient;


class DirectoryObject extends GraphObject
{

}