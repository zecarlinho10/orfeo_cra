<?php


namespace Office365\PHP\Client\GraphClient;


class TenantDetail extends DirectoryObject
{

}