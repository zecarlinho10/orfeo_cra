<?php


namespace Office365\PHP\Client\GraphClient;


class Device extends DirectoryObject
{

}