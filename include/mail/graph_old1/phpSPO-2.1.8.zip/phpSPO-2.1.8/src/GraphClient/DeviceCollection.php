<?php


namespace Office365\PHP\Client\GraphClient;

use Office365\PHP\Client\Runtime\ClientObjectCollection;

class DeviceCollection extends ClientObjectCollection
{

}