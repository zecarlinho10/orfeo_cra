<?php

namespace Office365\PHP\Client\SharePoint;
use Office365\PHP\Client\Runtime\ClientObjectCollection;

/**
 * Represents a collection of UserCustomAction resources.
 */
class UserCustomActionCollection extends ClientObjectCollection
{
    

}