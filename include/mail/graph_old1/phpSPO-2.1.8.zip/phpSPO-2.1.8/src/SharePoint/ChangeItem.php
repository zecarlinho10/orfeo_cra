<?php
namespace Office365\PHP\Client\SharePoint;


class ChangeItem extends Change
{
    /**
     * @var string
     */
    public $ItemId;

    /**
     * @var string
     */
    public $ListId;

    /**
     * @var string
     */
    public $WebId;

}