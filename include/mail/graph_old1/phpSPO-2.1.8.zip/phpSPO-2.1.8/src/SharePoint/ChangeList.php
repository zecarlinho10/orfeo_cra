<?php
namespace Office365\PHP\Client\SharePoint;


class ChangeList extends Change
{

    /**
     * @var string
     */
    public $ListId;

    /**
     * @var string
     */
    public $WebId;
}