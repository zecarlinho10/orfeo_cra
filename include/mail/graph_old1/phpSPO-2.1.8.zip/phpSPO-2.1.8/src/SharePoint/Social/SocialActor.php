<?php


namespace Office365\PHP\Client\SharePoint\Social;


use Office365\PHP\Client\Runtime\ClientValueObject;

class SocialActor extends ClientValueObject
{

}