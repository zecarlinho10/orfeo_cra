<?php


namespace Office365\PHP\Client\SharePoint\Social;
use Office365\PHP\Client\Runtime\ClientObject;

/**
 * Class SocialRestFeedManager
 */
class SocialRestFeedManager extends ClientObject
{

}