<?php

namespace Office365\PHP\Client\SharePoint\Taxonomy;



use Office365\PHP\Client\SharePoint\FieldLookup;

class TaxonomyField extends FieldLookup
{

}