<?php


namespace Office365\PHP\Client\SharePoint;


use Office365\PHP\Client\Runtime\ClientObject;

class ObjectSharingInformation extends ClientObject
{

}