<?php

namespace Office365\PHP\Client\SharePoint\DocumentSet;

use Office365\PHP\Client\Runtime\ClientObject;

class DocumentSet extends ClientObject
{

    

}