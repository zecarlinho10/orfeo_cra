<?php
namespace Office365\PHP\Client\SharePoint;


class ChangeFolder extends Change
{
    /**
     * @var string
     */
    public $UniqueId;

    /**
     * @var string
     */
    public $WebId;
}