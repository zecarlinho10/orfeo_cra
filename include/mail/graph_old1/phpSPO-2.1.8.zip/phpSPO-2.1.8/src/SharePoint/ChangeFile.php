<?php

namespace Office365\PHP\Client\SharePoint;


class ChangeFile extends Change
{
    /**
     * @var string
     */
    public $UniqueId;


    /**
     * @var string
     */
    public $WebId;
}