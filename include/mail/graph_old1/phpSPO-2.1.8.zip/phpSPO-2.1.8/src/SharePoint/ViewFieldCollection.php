<?php


namespace Office365\PHP\Client\SharePoint;
use Office365\PHP\Client\Runtime\ClientObjectCollection;

/**
 * Represents a collection of fields in a list view.
 */
class ViewFieldCollection extends ClientObjectCollection
{

}