<?php


namespace Office365\PHP\Client\SharePoint;


class FieldMultiChoice extends Field
{

}