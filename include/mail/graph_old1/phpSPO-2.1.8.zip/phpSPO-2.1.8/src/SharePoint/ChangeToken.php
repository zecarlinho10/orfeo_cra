<?php


namespace Office365\PHP\Client\SharePoint;


use Office365\PHP\Client\Runtime\ClientValueObject;

class ChangeToken extends ClientValueObject
{

    public $StringValue;
}