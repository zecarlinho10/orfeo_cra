<?php


namespace Office365\PHP\Client\SharePoint\UserProfiles;


use Office365\PHP\Client\Runtime\ClientObjectCollection;

class PersonPropertiesCollection extends ClientObjectCollection
{
}