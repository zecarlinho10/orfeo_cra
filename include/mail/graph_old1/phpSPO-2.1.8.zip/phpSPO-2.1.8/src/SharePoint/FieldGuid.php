<?php


namespace Office365\PHP\Client\SharePoint;


class FieldGuid extends Field
{

}