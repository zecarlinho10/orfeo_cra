<?php


namespace Office365\PHP\Client\SharePoint\Publishing;


class VideoProcessingStatus
{

    public const  PendingProcessing = 0;
    public const  Processing = 1;
}