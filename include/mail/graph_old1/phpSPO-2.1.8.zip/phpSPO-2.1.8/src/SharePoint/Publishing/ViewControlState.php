<?php


namespace Office365\PHP\Client\SharePoint\Publishing;


class ViewControlState
{

    const DefaultState = 0;

    const Popular = 1;

    const Newest = 2;

    const MyVideos = 3;

}