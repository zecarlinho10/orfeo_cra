<?php


namespace Office365\PHP\Client\SharePoint\Publishing;


use Office365\PHP\Client\Runtime\ClientObject;

class VideoThumbnail extends ClientObject
{

}