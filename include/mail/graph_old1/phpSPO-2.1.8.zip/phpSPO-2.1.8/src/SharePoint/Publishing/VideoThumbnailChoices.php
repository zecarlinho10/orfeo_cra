<?php


namespace Office365\PHP\Client\SharePoint\Publishing;


class VideoThumbnailChoices
{
    const Custom = 0;

    const First = 1;

    const Second = 2;

    const Third = 3;

    const Fourth = 4;

    const Fifth	 = 5;
}