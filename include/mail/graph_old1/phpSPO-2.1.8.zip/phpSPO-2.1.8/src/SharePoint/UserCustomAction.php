<?php

namespace Office365\PHP\Client\SharePoint;
use Office365\PHP\Client\Runtime\ClientObject;

/**
 * Represents a custom action associated with a SharePoint list, Web site, or subsite.
 */
class UserCustomAction extends ClientObject
{

}