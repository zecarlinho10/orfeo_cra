<?php
/**
 * Represents the value of a user field for a list item. Inherits from SP.FieldLookupValue.
 */

namespace Office365\PHP\Client\SharePoint;


class FieldUserValue extends FieldLookupValue
{

}