<?php

namespace Office365\PHP\Client\SharePoint;


class FieldLookup extends Field
{

}