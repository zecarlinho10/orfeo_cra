<?php

namespace Office365\PHP\Client\SharePoint;

class ChangeWeb extends Change
{
    /**
     * @var string
     */
    public $WebId;

}