<?php


namespace Office365\PHP\Client\SharePoint;


class FieldMultiLineText extends Field
{

}