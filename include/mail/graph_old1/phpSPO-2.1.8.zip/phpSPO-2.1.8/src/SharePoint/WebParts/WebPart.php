<?php
namespace Office365\PHP\Client\SharePoint\WebParts;

use Office365\PHP\Client\Runtime\ClientObject;

class WebPart extends ClientObject
{

}