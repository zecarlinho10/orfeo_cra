<?php


namespace Office365\PHP\Client\SharePoint;


class FieldChoice extends Field
{

}