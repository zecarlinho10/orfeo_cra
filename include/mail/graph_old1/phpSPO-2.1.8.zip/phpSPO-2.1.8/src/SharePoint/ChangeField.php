<?php


namespace Office365\PHP\Client\SharePoint;


class ChangeField extends Change
{
    /**
     * @var string
     */
    public $FieldId;

    /**
     * @var string
     */
    public $WebId;
}