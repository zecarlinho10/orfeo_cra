<?php

namespace Office365\PHP\Client\SharePoint;


use Office365\PHP\Client\Runtime\ClientObjectCollection;

class ChangeCollection extends ClientObjectCollection
{
     
}