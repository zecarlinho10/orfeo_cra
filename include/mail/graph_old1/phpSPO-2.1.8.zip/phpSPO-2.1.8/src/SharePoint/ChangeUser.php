<?php


namespace Office365\PHP\Client\SharePoint;


class ChangeUser extends Change
{
    /**
     * @var bool
     */
    public $Activate;

    /**
     * @var string
     */
    public $UserId;
}