<?php


namespace Office365\PHP\Client\OneDrive;


class FileCollection extends ItemCollection
{

}