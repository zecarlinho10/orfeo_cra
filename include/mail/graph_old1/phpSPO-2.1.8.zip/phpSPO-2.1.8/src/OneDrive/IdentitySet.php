<?php


namespace Office365\PHP\Client\FileServices;


use Office365\PHP\Client\Runtime\ClientObject;

class IdentitySet extends ClientObject
{

}