<?php


namespace Office365\PHP\Client\OneDrive;

class FolderCollection extends ItemCollection
{

}