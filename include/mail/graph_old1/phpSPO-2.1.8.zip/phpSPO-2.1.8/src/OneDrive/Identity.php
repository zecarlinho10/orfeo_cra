<?php


namespace Office365\PHP\Client\OneDrive;


use Office365\PHP\Client\Runtime\ClientObject;

class Identity extends ClientObject
{

}