<?php


namespace Office365\PHP\Client\FileServices;


use Office365\PHP\Client\Runtime\ClientObject;

class ImageFacet extends ClientObject
{

}