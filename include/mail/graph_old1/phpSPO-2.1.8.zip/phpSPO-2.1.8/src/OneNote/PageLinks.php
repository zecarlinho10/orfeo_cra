<?php


namespace Office365\PHP\Client\OneNote;

use Office365\PHP\Client\Runtime\ClientObjectCollection;

class PageLinks extends ClientObjectCollection
{

}