<?php


namespace Office365\PHP\Client\OneNote;


class UserRole
{
    const Owner = 0;
    const Contributor = 1;
    const Reader = 2;
    const None = 3;
}