<?php


namespace Office365\PHP\Client\OneNote;


class PatchActionType
{
    const Replace = 0;
    const Append = 1;
    const Delete = 2;
    const Insert = 3;
    const Prepend = 4;
}