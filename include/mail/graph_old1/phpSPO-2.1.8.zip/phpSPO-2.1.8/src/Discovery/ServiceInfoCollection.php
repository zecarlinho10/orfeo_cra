<?php


namespace Office365\PHP\Client\Discovery;


use Office365\PHP\Client\Runtime\ClientValueObjectCollection;


class ServiceInfoCollection extends ClientValueObjectCollection
{

}