<?php


namespace Office365\PHP\Client\OutlookServices;


class FileAttachmentCollection extends AttachmentCollection
{

}