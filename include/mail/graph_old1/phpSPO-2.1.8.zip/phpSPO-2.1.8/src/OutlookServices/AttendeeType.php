<?php


namespace Office365\PHP\Client\OutlookServices;


class AttendeeType
{
    const Required = "Required";
    const Optional = "Optional";
    const Resource = "Resource";
}