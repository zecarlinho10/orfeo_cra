<?php


namespace Office365\PHP\Client\OutlookServices;


class WeekIndex
{
    const First = "First";
    const Second = "Second";
    const Third = "Third";
    const Fourth = "Fourth";
    const Last = "Last";
}