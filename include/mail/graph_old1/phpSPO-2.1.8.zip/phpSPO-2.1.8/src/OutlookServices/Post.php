<?php


namespace Office365\PHP\Client\OutlookServices;


class Post extends Item
{

}