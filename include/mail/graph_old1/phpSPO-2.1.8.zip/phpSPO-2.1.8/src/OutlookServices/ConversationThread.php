<?php


namespace Office365\PHP\Client\OutlookServices;


class ConversationThread extends OutlookEntity
{

}