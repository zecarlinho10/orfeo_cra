<?php


namespace Office365\PHP\Client\OutlookServices;


class RecurrenceRangeType
{
    const EndDate = 0;
    const NoEnd = 1;
    const Numbered = 2;
}