<?php


namespace Office365\PHP\Client\OutlookServices;


class CalendarColor
{
    const Auto = -1;
    const LightBlue = 0;
    const LightGreen = 1;
    const LightOrange = 2;
    const LightGray = 3;
    const LightYellow = 4;
    const LightTeal = 5;
    const LightPink = 6;
    const LightBrown = 7;
    const LightRed = 8;
    const MaxColor = 9;
}