<?php


namespace Office365\PHP\Client\OutlookServices;


class RecurrencePatternType
{
    const Daily = 0;
    const Weekly = 1;
    const AbsoluteMonthly = 2;
    const RelativeMonthly = 3;
    const AbsoluteYearly = 4;
    const RelativeYearly = 5;
}