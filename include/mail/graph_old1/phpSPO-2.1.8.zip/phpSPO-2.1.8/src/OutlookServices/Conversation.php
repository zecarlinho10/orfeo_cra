<?php


namespace Office365\PHP\Client\OutlookServices;

/**
 * Class Conversation
 */
class Conversation extends OutlookEntity
{

}