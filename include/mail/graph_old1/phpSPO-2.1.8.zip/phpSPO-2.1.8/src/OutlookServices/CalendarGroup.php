<?php


namespace Office365\PHP\Client\OutlookServices;


/**
 * A group of calendars.
 */
class CalendarGroup extends OutlookEntity
{

}