<?php

require_once(__DIR__ . '/../examples/Settings.php');
require_once('OutlookServicesTestCase.php');
require_once('SharePointTestCase.php');
require_once('TestUtilities.php');
require_once(__DIR__ . '/../vendor/autoload.php');



